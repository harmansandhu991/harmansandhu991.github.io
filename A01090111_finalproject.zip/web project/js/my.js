
function myFunction() 
{
  var x = document.getElementById("myEmail").pattern;
  document.getElementById("demo").innerHTML = x;
}
        
function validateForm() {
  var x = document.forms["myForm"]["name"].value;
  if (x == "") {
    alert("Name must be filled out");
    return false;
  } else{
      alert("Thanks For Subscription");
      
  }

}
function al() {
      alert("Thanks For Feedback");
      
  }
function displayNextImage() {
              x = (x === images.length - 1) ? 0 : x + 1;
              document.getElementById("img").src = images[x];
          }

          function displayPreviousImage() {
              x = (x <= 0) ? images.length - 1 : x - 1;
              document.getElementById("img").src = images[x];
          }

          function startTimer() {
              setInterval(displayNextImage, 3000);
          }

          var images = [], x = -1;
          images[0] = "images/i1.jpg";
          images[1] = "images/i2.jpg";
          images[2] = "images/i3.jpg";
        images[3] = "images/ch1.jpg";
          images[4] = "images/ch2.jpg";
          images[5] = "images/ch3.jpg";
        images[6] = "images/g1.jpg";
          images[7] = "images/g2.jpg";
          images[8] = "images/g3.jpg";


